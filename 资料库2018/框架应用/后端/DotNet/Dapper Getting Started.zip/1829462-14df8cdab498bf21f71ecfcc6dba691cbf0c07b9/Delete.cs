// Dapper - Delete
using (var connection = MvcApplication.GetOpenConnection()) {
  connection.Execute(@"delete from Posts where id = @id", new { id = 1 });
}