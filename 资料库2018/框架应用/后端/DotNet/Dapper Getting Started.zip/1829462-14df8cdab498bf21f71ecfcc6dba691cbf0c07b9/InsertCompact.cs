// Dapper Insert Using SQL Compact Edition
using (var connection = MvcApplication.GetOpenConnection()) {
  var post = new Post { 
      Title = "Title 1", 
      Text = "Text 1", 
      PublishDate = DateTime.Now };
  connection.Execute(@"insert into Posts(Title, Text, PublishDate)
      values (@Title, @Text, @PublishDate);", 
      new { post.Title, post.Text, post.PublishDate });
 
  post.ID = (int)connection.Query(@"select @@IDENTITY as ID").First().ID;
}
