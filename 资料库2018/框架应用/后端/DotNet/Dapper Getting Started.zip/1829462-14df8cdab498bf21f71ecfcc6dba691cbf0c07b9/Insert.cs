// Dapper - Insert
using (var connection = MvcApplication.GetOpenConnection()) {
  var post = new Post { 
      Title = "Title 1", 
      Text = "Text 1", 
     PublishDate = DateTime.Now };
  post.ID = connection.Query<int>(@"insert into Posts(Title, Text, PublishDate)
    values (@Title, @Text, @PublishDate); 
    select cast(scope_identity() as int)", 
    new { post.Title, post.Text, post.PublishDate }).First();
}
