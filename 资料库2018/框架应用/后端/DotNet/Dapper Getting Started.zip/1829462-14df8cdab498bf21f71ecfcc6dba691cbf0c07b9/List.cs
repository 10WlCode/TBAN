// Dapper – Simple List
using (var connection = ConnectionFactory.GetOpenConnection()) { 
  var posts = connection.Query<Post>("select * from posts").ToList();
}