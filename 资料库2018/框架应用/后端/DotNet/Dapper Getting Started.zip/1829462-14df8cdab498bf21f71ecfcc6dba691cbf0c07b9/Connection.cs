public class ConnectionFactory {
  public static DbConnection GetOpenConnection() {
    var connection = new SqlConnection("MyConnectionString");
    connection.Open();
 
    return connection;
  }
}