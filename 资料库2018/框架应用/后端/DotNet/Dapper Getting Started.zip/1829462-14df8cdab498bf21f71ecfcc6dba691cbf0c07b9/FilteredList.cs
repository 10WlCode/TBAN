// Dapper – Filtered List
using (var connection = ConnectionFactory.GetOpenConnection()) {
  var posts = connection.Query<Post>("select * from posts where text like @text", 
    new { text = "%Some Value%" }).ToList();
}