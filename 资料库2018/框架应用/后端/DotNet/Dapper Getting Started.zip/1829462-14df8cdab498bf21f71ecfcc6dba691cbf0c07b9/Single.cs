// Dapper - Single
using (var connection = MvcApplication.GetOpenConnection()) {
  var post = connection.Query<Post>("select * from posts where id = @id", 
    new { id = 1 }).First();
}
