// Dapper - Update
using (var connection = MvcApplication.GetOpenConnection()) {
  var post = connection.Query<Post>( 
    "select * from posts where id = @id", new { id = 1 } ).First();
  post.Title = "New Title";
  connection.Execute(@"update Posts set Title = @Title, 
    Text = @Text, PublishDate = @PublishDate where ID = @id;", 
    new { post.ID, post.Title, post.Text, post.PublishDate });
}